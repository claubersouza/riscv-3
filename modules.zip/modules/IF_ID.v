////////////////////////////////////////////////////////////
// stage 1: fetch/decode
////////////////////////////////////////////////////////////
module IF_ID 
#(
    parameter [31:0]             RESET = 32'h0000_0000
    )
(
input                   clk,
input                   reset,
input                   stall,
output reg              exception,  

// interface of instruction Memory
input                   inst_mem_is_valid,
input           [31: 0] inst_mem_read_data

);

//////////////// Including OPCODES ////////////////////////////
`include "opcode.vh"

// function [4:0] somar_4bits (input [3:0] num1, input [3:0] num2);
// begin
//   somar_4bits = num1 + num2;
// end
// endfunction
task teste2 (input [31:0] inst1, output reg [31:0] value);
  begin
    if (inst1 == 32'h078007D3) begin
      value = 32'h07800793;
    end
    else begin
      value = inst1;
    end
  end
endtask

function [31:0] teste (input [31:0] inst1);
    // reg [31:0] inst2_local; // Variável local para armazenar o valor a ser retornado

    begin
        if (inst1 == 32'h078007D3) begin
            teste = inst1;
              
        end
        else begin
           teste = inst1;
        end
         // Atribui o valor a ser retornado (para inst2)
    end
endfunction
////////////////////////////////////////////////////////////////
// IF stage Start
////////////////////////////////////////////////////////////////
assign pipe.instruction                 = pipe.stall_read? NOP:teste(inst_mem_read_data);

integer counter ;
reg [31: 0] reg2;
initial begin
    counter = 0;
    
end
always @(pipe.instruction) begin
    counter = counter + 1;
end

// check for illegal instruction(instruction not in RV-32I architecture)

always @(posedge clk or negedge reset) 
begin
if (!reset)
    exception           <= 1'b0;
    
else if (pipe.illegal_inst || pipe.inst_mem_address[1:0] != 0)
    exception           <= 1'b1;
end


// Stall read assignment for stalling while reading 

always @(posedge clk or negedge reset) 
begin
if (!reset) 
begin
    pipe.stall_read             <= 1'b1;
end else 
begin
    pipe.stall_read             <= stall;
end
end

////////////////////////////////////////////////////////////////
// IF stage end
////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
// ID stage 
////////////////////////////////////////////////////////////////

always @* 
begin
pipe.immediate                     = 32'h0;
pipe.illegal_inst                  = 1'b0;
// $display("Valor:%h",pipe.instruction[`OPCODE]);
 
case(pipe.instruction[`OPCODE])
    JALR  : pipe.immediate      = {{20{pipe.instruction[31]}}, pipe.instruction[31:20]}; // I-Type 
    BRANCH: pipe.immediate      = {{20{pipe.instruction[31]}}, pipe.instruction[7], pipe.instruction[30:25], pipe.instruction[11:8], 1'b0}; // B-type
    LOAD  : pipe.immediate      = {{20{pipe.instruction[31]}}, pipe.instruction[31:20]}; // I-type
    STORE : pipe.immediate      = {{20{pipe.instruction[31]}}, pipe.instruction[31:25], pipe.instruction[11:7]}; // S-type
    ARITHI: pipe.immediate      = (pipe.instruction[`FUNC3] == SLL || pipe.instruction[`FUNC3] == SR) ? {27'h0, pipe.instruction[24:20]} : {{20{pipe.instruction[31]}}, pipe.instruction[31:20]}; // I-type
    ARITHR: pipe.immediate      = 'd0; // R-type
    LUI   : pipe.immediate      = {pipe.instruction[31:12], 12'd0}; // U-type
    JAL   : pipe.immediate      = {{12{pipe.instruction[31]}}, pipe.instruction[19:12], pipe.instruction[20], pipe.instruction[30:21], 1'b0}; // J-type
    CUSTOM: pipe.immediate     = (pipe.instruction[`FUNC3] == SLL || pipe.instruction[`FUNC3] == SR) ? {27'h0, pipe.instruction[24:20]} : {{20{pipe.instruction[31]}}, pipe.instruction[31:20]}; // I-type
    CUSTOM2: pipe.immediate     = (pipe.instruction[`FUNC3] == SLL || pipe.instruction[`FUNC3] == SR) ? {27'h0, pipe.instruction[24:20]} : {{20{pipe.instruction[31]}}, pipe.instruction[31:20]}; // I-type
    CUSTOM3: pipe.immediate     = (pipe.instruction[`FUNC3] == SLL || pipe.instruction[`FUNC3] == SR) ? {27'h0, pipe.instruction[24:20]} : {{20{pipe.instruction[31]}}, pipe.instruction[31:20]}; // I-type
    CUSTOM4: pipe.immediate     = (pipe.instruction[`FUNC3] == SLL || pipe.instruction[`FUNC3] == SR) ? {27'h0, pipe.instruction[24:20]} : {{20{pipe.instruction[31]}}, pipe.instruction[31:20]}; // I-type
    default: begin // illegal instruction
        pipe.illegal_inst    = 1'b1;
    end
endcase
end

always @(posedge clk or negedge reset) 
begin

// If reset of the system is performed, reset all the values. 

if (!reset) 
begin
    pipe.execute_immediate      <= 32'h0;
    pipe.immediate_sel          <= 1'b0;
    pipe.alu                    <= 1'b0;
    pipe.custom                 <= 1'b0;
    pipe.custom2                <= 1'b0;
    pipe.custom3                <= 1'b0;
    pipe.custom4                <= 1'b0;
    pipe.custom_write_x10       <= 1'b0;
     pipe.custom_write_x2       <= 1'b0;
     pipe.custom_write_x3       <= 1'b0;
    pipe.custom_write_x4       <= 1'b0;
    pipe.jal                    <= 1'b0;
    pipe.jalr                   <= 1'b0;
    pipe.branch                 <= 1'b0;
    pipe.lui                    <= 1'b0;
    pipe.pc                     <= RESET;
    pipe.src1_select            <= 5'h0;
    pipe.src2_select            <= 5'h0;
    pipe.dest_reg_sel           <= 5'h0;
    pipe.alu_operation          <= 3'h0;
    pipe.arithsubtype           <= 1'b0;
    pipe.mem_write              <= 1'b0;
    pipe.mem_to_reg             <= 1'b0;
end 
else if(!pipe.stall_read) 
begin  
    //  $display("Valor:%b",pipe.instruction[`OPCODE]);    
                     // else take the values from the IF stage and decode it to pass values to corresponding wires
    pipe.execute_immediate      <= pipe.immediate;
    pipe.immediate_sel          <= (pipe.instruction[`OPCODE] == JALR  ) || (pipe.instruction[`OPCODE] == LOAD  ) ||
                                    (pipe.instruction[`OPCODE] == ARITHI) || (pipe.instruction[`OPCODE] == CUSTOM) ;
    pipe.alu                    <= (pipe.instruction[`OPCODE] == ARITHI) ||
                                   (pipe.instruction[`OPCODE] == ARITHR);
    pipe.lui                    <= pipe.instruction[`OPCODE] == LUI;
    pipe.custom                 <= pipe.instruction[`OPCODE] == CUSTOM;
    // pipe.custom2                <= pipe.instruction[`OPCODE] == CUSTOM2;
    // Instrução customizada exata que escreve 4 em x10.
    pipe.custom_write_x10       <= (pipe.instruction == 32'h00010553);
    pipe.custom_write_x2        <= (pipe.instruction == 32'h00010573);
    pipe.custom_write_x3       <= (pipe.instruction ==  32'h0001057B);
    pipe.custom_write_x4       <= (pipe.instruction ==  32'h0001057D);
    pipe.jal                    <= pipe.instruction[`OPCODE] == JAL;
    pipe.jalr                   <= pipe.instruction[`OPCODE] == JALR;
    pipe.branch                 <= pipe.instruction[`OPCODE] == BRANCH;
    pipe.pc                     <= pipe.inst_fetch_pc;
    pipe.src1_select            <= pipe.instruction[`RS1];
    pipe.src2_select            <= pipe.instruction[`RS2];
    pipe.dest_reg_sel           <= pipe.instruction[`RD];
    pipe.alu_operation          <= pipe.instruction[`FUNC3];
    pipe.arithsubtype           <= pipe.instruction[`SUBTYPE] && !(pipe.instruction[`OPCODE] == ARITHI && pipe.instruction[`FUNC3] == ADD);
    pipe.mem_write              <= pipe.instruction[`OPCODE] == STORE;
    pipe.mem_to_reg             <= pipe.instruction[`OPCODE] == LOAD;
    
end

end



// Data forwarding and storing data in respective registers depending on conditions of write stalls, and other conditions 

assign pipe.reg_rdata1[31:0] =
                    (pipe.src1_select == 5'd0) ? 32'd0 :
                    (!pipe.wb_stall && pipe.wb_custom_write_x10 &&
                     (pipe.src1_select == 5'd8))  ? (pipe.wb_custom_x2_value + 32'd48) :
                    (!pipe.wb_stall && pipe.wb_custom_write_x10 &&
                     (pipe.src1_select == 5'd15)) ? 32'd6 :
                    (!pipe.wb_stall && pipe.wb_alu_to_reg &&
                     (pipe.wb_dest_reg_sel != 5'd0) &&
                     (pipe.wb_dest_reg_sel == pipe.src1_select)) ?
                        (pipe.wb_mem_to_reg ? pipe.wb_read_data : pipe.wb_result) :
                    pipe.regs[pipe.src1_select];

assign pipe.reg_rdata2[31:0] =
                    (pipe.src2_select == 5'd0) ? 32'd0 :
                    (!pipe.wb_stall && pipe.wb_custom_write_x10 &&
                     (pipe.src2_select == 5'd8))  ? (pipe.wb_custom_x2_value + 32'd48) :
                    (!pipe.wb_stall && pipe.wb_custom_write_x10 &&
                     (pipe.src2_select == 5'd15)) ? 32'd6 :
                    (!pipe.wb_stall && pipe.wb_alu_to_reg &&
                     (pipe.wb_dest_reg_sel != 5'd0) &&
                     (pipe.wb_dest_reg_sel == pipe.src2_select)) ?
                        (pipe.wb_mem_to_reg ? pipe.wb_read_data : pipe.wb_result) :
                    pipe.regs[pipe.src2_select];


////////////////////////////////////////////////////////////
// Register file
////////////////////////////////////////////////////////////

integer i;
always @(posedge clk or negedge reset) 
begin
if (!reset) 
begin
    for(i = 1; i < 32; i=i+1) 
    begin
        pipe.regs[i] <= 32'h0;
    end
    pipe.regs[2] <= 32'h00000fff;
end 
else if (pipe.wb_custom_write_x10 && !pipe.stall_read && !pipe.wb_stall)
begin
    // Equivalente a:
    // 03010413  addi x8,  x2, 48
    // 00300793  addi x15, x0, 3
    // fef42423  sw   x15, -24(x8)
    // 00600793  addi x15, x0, 6
    // A escrita de 3 na memoria[x2 + 24] ocorre pelo caminho de store.
    pipe.regs[8]  <= pipe.wb_custom_x2_value + 32'd48;
    pipe.regs[15] <= 32'd6;
end
else if (pipe.wb_custom_write_x2 && !pipe.stall_read && !pipe.wb_stall)
begin
    // Único ponto de escrita da instrução 00010573.
pipe.regs[17] <= pipe.regs[10];
pipe.regs[6]  <= pipe.regs[10];
pipe.regs[7]  <= 32'd0;
end
else if (pipe.wb_custom_write_x3 && !pipe.stall_read && !pipe.wb_stall)
begin
    // Único ponto de escrita da instrução 00010573.
pipe.regs[14] <= pipe.regs[10];
pipe.regs[11] <= pipe.regs[10];
pipe.regs[12] <= 32'd0;
end
else if (pipe.wb_custom_write_x4 && !pipe.stall_read && !pipe.wb_stall)
begin
    // Único ponto de escrita da instrução 00010573.
pipe.regs[15] <= pipe.regs[2] + 32'd3;
$display("Passou aqui: %h", pipe.regs[15] );
    // $display("Valor:%h",pipe.instruction[`OPCODE]); 

end
else if (pipe.wb_alu_to_reg && !pipe.stall_read && !pipe.wb_stall &&
         (pipe.wb_dest_reg_sel != 5'd0))
begin
    pipe.regs[pipe.wb_dest_reg_sel] <= pipe.wb_mem_to_reg ?
                                       pipe.wb_read_data : pipe.wb_result;
end
end




endmodule
