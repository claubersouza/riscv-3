#include <stdio.h>

int main(void) {
    int a = 4;
    int b = 50;
    int c = a-b;
    return c;
}
