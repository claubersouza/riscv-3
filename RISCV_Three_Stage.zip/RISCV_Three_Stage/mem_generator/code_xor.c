#include <stdio.h>

int main(void) {
    int a = 4;
    int c = a^1;
    return c;
}
