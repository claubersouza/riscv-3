#include <stdio.h>

int main(void) {
    int a = 100;
    int b = 2;
    int c = a+b;
    return c;
}
