#include <stdio.h>
#include "crc16.h"

uint8_t data[] = {0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39};

int main(void) {

  uint16_t crc;
  crc = crc16(data, sizeof(data));
  // printf("crc16: 0x%04X\n", crc);
  
  return 0;
}



uint16_t crc16(const uint8_t *data, size_t length) {
  uint16_t crc = 0xFFFF;
  for (size_t i = 0; i < length; i++) {
    crc ^= (uint16_t)data[i] << 8;
    for (uint8_t j = 0; j < 8; j++) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ 0x1021; // POLYNOMIAL
      } else {
        crc <<= 1;
      }
    }
  }
  return(crc);
}